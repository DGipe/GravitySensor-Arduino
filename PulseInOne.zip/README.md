Use a hardware interrupt to emulate the Arduino::pulseIn functionality without pausing code execution while waiting for the pulse
See http://arduino.cc/en/Reference/Interrupts
